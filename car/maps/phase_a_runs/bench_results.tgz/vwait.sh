#!/bin/bash
# vwait.sh TAG... : wait until every batch_TAG.txt has its C-lines, then print summaries + each run
cd ~/phase_a/bench
for i in $(seq 120); do ok=1; for t in "$@"; do grep -q '^C[123]:' batch_$t.txt 2>/dev/null || ok=0; done; [ $ok = 1 ] && break; sleep 10; done
for t in "$@"; do echo "== $t"; cat batch_$t.txt; done
python3 - "$@" <<'PY'
import json, glob, sys
for t in sys.argv[1:]:
  for f in sorted(glob.glob(f'results/{t}_*.json')):
    r = json.load(open(f)); print(f'{f[8:]:24s} reached {r["reached"]!s:5s} {r["time_s"]:6.1f} s recov {r["recoveries"]:2d} rev {r.get("reverse_s", 0):5.1f} s flips {r.get("flips_per_s", 0):.2f} lock {r.get("full_lock_pct", 0):4.1f}% v {r.get("mean_speed", 0):.2f} end {r.get("end")}')
PY
